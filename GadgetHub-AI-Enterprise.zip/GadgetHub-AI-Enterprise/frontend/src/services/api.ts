const BASE = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000/api/v1'
async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${BASE}${path}`, { headers: {'Content-Type':'application/json'}, ...options })
  if (!response.ok) throw new Error(`API error ${response.status}`)
  return response.json()
}
export const api = {
  dashboard: () => request<any>('/dashboard'),
  transactions: () => request<any[]>('/transactions'),
  alerts: () => request<any[]>('/alerts'),
  chargebacks: () => request<any[]>('/chargebacks'),
  score: (payload: any) => request<any>('/score', {method:'POST', body:JSON.stringify(payload)}),
  resolveAlert: (id:number) => request<any>(`/alerts/${id}/resolve`, {method:'PATCH'})
}
