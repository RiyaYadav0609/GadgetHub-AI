# GadgetHub AI Enterprise — Fraud Intelligence Platform

A runnable full-stack demonstration platform for GadgetHub's fraud and chargeback case study.

## Stack
- Backend: Python 3.11+, FastAPI, SQLAlchemy, SQLite, Pydantic
- Frontend: React, TypeScript, Vite, Recharts, Lucide
- Detection: transparent rules + weighted risk scoring + explainable signals
- Data: synthetic demo transactions only

## Important
This is an educational/demo implementation. It does not connect to a payment gateway, process real card data, or provide production-grade authentication/compliance guarantees. Never enter real PAN/CVV or customer personal data. Production deployment requires security review, secrets management, PCI DSS scope assessment, tested migrations, monitoring, and integration with an acquirer/payment processor.

## Run locally (Windows)
1. Install Python 3.11+ and Node.js 20+.
2. Open a terminal in this folder.
3. Run `scripts\setup.bat`
4. Run `scripts\start_backend.bat`
5. In another terminal run `scripts\start_frontend.bat`
6. Open http://localhost:5173

Backend API docs: http://127.0.0.1:8000/docs

## Run locally (macOS/Linux)
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r backend/requirements.txt
cd backend && uvicorn app.main:app --reload
```
In another terminal:
```bash
cd frontend
npm install
npm run dev
```

## Demo credentials
The demo UI opens directly in demo mode. The API exposes a demo login endpoint:
- email: `analyst@gadgethub.demo`
- password: `Demo@12345`

Do not reuse these credentials in a deployed environment.

## Risk policy (illustrative starting point)
- 0–24: APPROVE
- 25–49: CHALLENGE
- 50–74: REVIEW
- 75–100: DECLINE

These are configurable demonstration thresholds, not universal industry thresholds. Calibrate using GadgetHub's labeled historical data, fraud loss, false declines, approval rate and operational capacity.

## Case-study operating targets
- Stop low-value card testing using velocity controls, rate limits, device/IP signals and processor-level controls.
- Step up authentication for suspicious account changes and high-risk payments.
- Preserve immutable event history and dispute evidence.
- Monitor dispute ratio and Visa Acquirer Monitoring Program (VAMP) metrics using the applicable acquirer/network definitions and current regional thresholds. Confirm the live threshold with the acquirer; do not hard-code a single threshold as universally applicable.
