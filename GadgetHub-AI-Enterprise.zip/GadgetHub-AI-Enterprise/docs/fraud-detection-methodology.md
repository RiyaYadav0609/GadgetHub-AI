# Fraud detection methodology

## Threats in the case
1. Card testing: attackers submit many low-value authorizations to identify valid stolen card credentials.
2. Account takeover: an attacker gains access to a genuine customer's account and changes credentials, address or device before purchasing.
3. New-address / friendly-fraud risk: high-value electronics are shipped to an address not previously associated with the customer; this is a signal, not proof of fraud.
4. Velocity / bot abuse: automated bursts create many attempts across cards, accounts, devices or IP ranges.
5. Chargeback abuse and genuine disputes: unauthorized-payment claims, non-delivery, duplicate processing or product-not-as-described disputes.

## Layered controls
Before payment: bot management, signup/login protections, device reputation, address-change cooling-off, breached credential checks, velocity limits by account/device/IP/payment token, and risk-based 3DS.
During payment: processor authorization controls, tokenization, AVS/CVV response handling (never retain CVV), 3DS/SCA where applicable, velocity and behavioral rules, risk scoring, idempotency and adaptive challenge.
After payment: shipment holds for high-risk orders, delivery confirmation, customer notifications, account recovery controls, alert triage, dispute evidence preservation and feedback labels.

## Illustrative score bands
- 0–24 APPROVE
- 25–49 CHALLENGE
- 50–74 REVIEW
- 75–100 DECLINE

The bands are demonstration defaults. Calibrate with a time-based validation set, fraud loss, approval rate, false declines, manual-review capacity and customer friction.

## Operations
Daily: review critical alerts, monitor authorization and decline spikes, inspect micro-authorization velocity, clear review queue by SLA, review upcoming dispute deadlines, reconcile processor outcomes and label confirmed fraud.
Weekly: analyze attack patterns, device/address clusters, false positives, chargeback reason codes, win rate, feature drift, rule overrides and threshold performance; tune controls with rollback plans.

## Evidence for disputes
Keep order confirmation, item/SKU and price, customer communications, processor transaction/authorization reference, AVS/CVV result codes where permitted, 3DS authentication result, device/IP and timestamped risk signals, account history, shipping address history, carrier tracking, delivery confirmation, proof of pickup/signature where applicable, refund/cancellation policy acceptance and immutable analyst/audit events. Never store CVV after authorization or expose full PAN.

## Metrics
Track fraud loss rate (basis points), dispute ratio by applicable scheme/acquirer definition, authorization approval rate, false-decline rate, challenge completion rate, manual-review rate, chargeback representment win rate, time-to-detect, time-to-review, card-testing attempts blocked and alert precision.

## Visa VAMP
VAMP is a Visa monitoring program for fraud and dispute activity. The applicable ratio, threshold, regional treatment, acquirer obligations and effective dates may change. For a real India merchant, confirm the current applicable threshold and calculation with the acquiring bank/processor and Visa program documentation. Do not treat a single internet-circulated threshold as universally valid.
