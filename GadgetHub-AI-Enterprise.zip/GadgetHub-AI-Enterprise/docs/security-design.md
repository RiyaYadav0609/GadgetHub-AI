# Security design notes

This is a local educational demo, not a production security boundary. Before production:
- replace demo auth with OIDC/SSO, MFA, secure session handling and server-side RBAC;
- use a secrets manager, rotate keys and enforce TLS;
- use PostgreSQL migrations, backups, least-privilege DB roles and encryption at rest;
- validate and rate-limit all inputs; protect against CSRF/SSRF and injection;
- maintain immutable, access-controlled audit logs;
- minimize PII and define retention/deletion policies;
- never store PAN/CVV; use payment-provider tokenization;
- add dependency scanning, SAST/DAST, penetration testing and incident response runbooks.
