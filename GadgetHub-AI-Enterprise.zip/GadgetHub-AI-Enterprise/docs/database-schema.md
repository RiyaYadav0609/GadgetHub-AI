# Data model

- transactions: synthetic payment event, amount, device reference, velocity, address novelty, risk score and decision.
- fraud_alerts: alert title, severity, category, description and status.
- chargebacks: dispute case reference, transaction reference, reason, amount, response deadline and status.

Never store raw card number or CVV. In production, store processor tokens and permitted response metadata only.
