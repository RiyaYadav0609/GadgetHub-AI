# Architecture

Browser (React/Vite) → FastAPI REST API → service layer → SQLAlchemy → SQLite demo database.

The scoring path is:
1. API validates transaction features.
2. Detection modules evaluate card-testing, address, account-age/device and velocity signals.
3. Fraud service aggregates points, caps score at 100 and maps it to a decision band.
4. API returns score, decision, reasons and policy ranges.

Production evolution: replace SQLite with PostgreSQL; add Redis/event streaming; use a payment processor's tokenized payment references; isolate model serving; add signed event ingestion, secrets vault, WAF, rate limits, alerting and disaster recovery.
