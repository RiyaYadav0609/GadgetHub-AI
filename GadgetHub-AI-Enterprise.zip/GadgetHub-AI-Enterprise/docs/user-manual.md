# User manual

1. Start backend and frontend using scripts.
2. Overview shows synthetic KPIs, trend charts, risk distribution, latest transactions and priority alerts.
3. Transactions supports text filtering and CSV export.
4. Attack Simulator lets an analyst change transaction signals and see the risk decision with reasons.
5. Alerts lets an analyst resolve seeded alerts.
6. Chargebacks displays case deadlines and evidence reminders.
7. Model Monitoring and Reports explain which metrics need real labeled data and acquirer validation.
