# API

Base URL: `/api/v1`

- GET `/health` — service status
- GET `/dashboard` — KPI and chart aggregates
- GET `/transactions` — transaction list
- POST `/score` — assess a transaction feature payload
- GET `/alerts` — fraud alert queue
- PATCH `/alerts/{id}/resolve` — resolve an alert
- GET `/chargebacks` — dispute queue
- GET `/reports/metrics` — reporting summary and policy bands

Interactive OpenAPI: `http://127.0.0.1:8000/docs`
