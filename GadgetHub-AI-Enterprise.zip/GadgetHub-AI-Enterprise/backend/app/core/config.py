from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "GadgetHub AI Enterprise"
    app_env: str = "development"
    secret_key: str = "local-demo-secret-change-before-deployment"
    database_url: str = "sqlite:///./gadgethub.db"
    cors_origins: str = "http://localhost:5173"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
