from app.database.connection import Base, engine, SessionLocal
from app.models.entities import Transaction, FraudAlert, Chargeback
from app.services.fraud_service import assess_transaction

def seed_database():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if db.query(Transaction).count() == 0:
            samples = [
                ("GH-9001","Aarav Sharma",28999,"Smartphone X Pro","Noida",True,"dev-91",2,12),
                ("GH-9002","Meera Kapoor",84999,"Laptop Ultra 14","Delhi",False,"dev-22",1,900),
                ("GH-9003","Kabir Singh",1,"Card verification","Mumbai",False,"dev-bot-7",48,2),
                ("GH-9004","Isha Verma",56999,"Gaming Laptop","Pune",True,"dev-91",5,4),
                ("GH-9005","Dev Patel",1299,"Accessories bundle","Jaipur",False,"dev-45",1,430),
                ("GH-9006","Anaya Rao",74999,"Flagship Phone","Bengaluru",True,"dev-77",3,7),
                ("GH-9007","Rohan Das",1,"Card verification","Kolkata",False,"dev-bot-7",61,1),
                ("GH-9008","Sara Khan",45999,"Tablet Pro","Hyderabad",False,"dev-18",1,720),
            ]
            for ref, customer, amount, product, city, new_addr, device, attempts, age in samples:
                score, decision, reasons = assess_transaction(amount, new_addr, attempts, age, device)
                db.add(Transaction(reference=ref, customer=customer, amount=amount, product=product,
                    city=city, new_address=new_addr, device_id=device, attempts_10m=attempts,
                    account_age_days=age, risk_score=score, decision=decision,
                    status="BLOCKED" if decision=="DECLINE" else ("CHALLENGE_REQUIRED" if decision=="CHALLENGE" else "AUTHORIZED")))
        if db.query(FraudAlert).count() == 0:
            db.add_all([
                FraudAlert(title="Coordinated low-value authorization burst", severity="CRITICAL", category="CARD_TESTING",
                    description="Repeated ₹1 authorization attempts from a shared device fingerprint."),
                FraudAlert(title="New delivery address + high-value order", severity="HIGH", category="ADDRESS_RISK",
                    description="High-value electronics order with recently added delivery address."),
                FraudAlert(title="Unusual account access pattern", severity="MEDIUM", category="ACCOUNT_TAKEOVER",
                    description="New device and unusual activity preceding a payment.")
            ])
        if db.query(Chargeback).count() == 0:
            db.add_all([
                Chargeback(case_ref="CB-2026-041", transaction_ref="GH-9001", reason="Fraudulent / no cardholder authorization",
                    amount=28999, due_date="2026-11-19", status="NEEDS_EVIDENCE"),
                Chargeback(case_ref="CB-2026-038", transaction_ref="GH-9006", reason="Product not received",
                    amount=74999, due_date="2026-11-21", status="IN_PROGRESS")
            ])
        db.commit()
    finally:
        db.close()
