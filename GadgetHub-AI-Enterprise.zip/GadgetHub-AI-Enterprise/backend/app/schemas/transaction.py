from pydantic import BaseModel, Field
class ScoreRequest(BaseModel):
    amount: float = Field(gt=0, le=10000000)
    new_address: bool = False
    attempts_10m: int = Field(default=1, ge=1, le=10000)
    account_age_days: int = Field(default=365, ge=0, le=100000)
    device_id: str = "device-unknown"
