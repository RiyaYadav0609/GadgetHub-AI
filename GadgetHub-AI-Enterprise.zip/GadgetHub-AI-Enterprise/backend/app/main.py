from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.api.v1.router import api_router
from app.database.seed import seed_database

app = FastAPI(title=settings.app_name, version="1.0.0-demo",
    description="GadgetHub fraud intelligence and chargeback operations demo")
origins = [x.strip() for x in settings.cors_origins.split(",")]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"])
app.include_router(api_router, prefix="/api/v1")

@app.on_event("startup")
def startup():
    seed_database()

@app.get("/")
def root():
    return {"product":"GadgetHub AI Enterprise","status":"online","docs":"/docs"}
