from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database.connection import get_db
from app.models.entities import Transaction, FraudAlert, Chargeback
from app.schemas.transaction import ScoreRequest
from app.services.fraud_service import assess_transaction
from app.services.analytics_service import dashboard_summary

router = APIRouter()

@router.get("/health")
def health():
    return {"status": "healthy", "service": "GadgetHub Risk Engine", "version": "1.0.0-demo"}

@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db)):
    summary = dashboard_summary(db)
    return {
        **summary,
        "risk_distribution": [
            {"name":"Approve","value":sum(1 for t in db.query(Transaction).all() if t.decision=="APPROVE")},
            {"name":"Challenge","value":sum(1 for t in db.query(Transaction).all() if t.decision=="CHALLENGE")},
            {"name":"Review","value":sum(1 for t in db.query(Transaction).all() if t.decision=="REVIEW")},
            {"name":"Decline","value":sum(1 for t in db.query(Transaction).all() if t.decision=="DECLINE")}
        ],
        "weekly_trend":[
            {"day":"Mon","transactions":420,"fraud":18},{"day":"Tue","transactions":510,"fraud":23},
            {"day":"Wed","transactions":470,"fraud":20},{"day":"Thu","transactions":620,"fraud":31},
            {"day":"Fri","transactions":710,"fraud":38},{"day":"Sat","transactions":680,"fraud":29},
            {"day":"Sun","transactions":560,"fraud":25}
        ]
    }

@router.get("/transactions")
def transactions(db: Session = Depends(get_db)):
    rows = db.query(Transaction).order_by(Transaction.id.desc()).all()
    return [{"id":t.id,"reference":t.reference,"customer":t.customer,"amount":t.amount,
        "product":t.product,"city":t.city,"risk_score":t.risk_score,"decision":t.decision,
        "status":t.status,"new_address":t.new_address,"attempts_10m":t.attempts_10m} for t in rows]

@router.post("/score")
def score(payload: ScoreRequest):
    value, decision, reasons = assess_transaction(payload.amount, payload.new_address,
        payload.attempts_10m, payload.account_age_days, payload.device_id)
    return {"risk_score":value,"decision":decision,"reasons":reasons,
        "policy":{"approve":"0–24","challenge":"25–49","review":"50–74","decline":"75–100"}}

@router.get("/alerts")
def alerts(db: Session = Depends(get_db)):
    rows = db.query(FraudAlert).order_by(FraudAlert.id.desc()).all()
    return [{"id":a.id,"title":a.title,"severity":a.severity,"category":a.category,
        "description":a.description,"status":a.status} for a in rows]

@router.patch("/alerts/{alert_id}/resolve")
def resolve_alert(alert_id: int, db: Session = Depends(get_db)):
    alert = db.query(FraudAlert).filter(FraudAlert.id==alert_id).first()
    if not alert: raise HTTPException(404, "Alert not found")
    alert.status = "RESOLVED"; db.commit()
    return {"message":"Alert resolved","id":alert_id}

@router.get("/chargebacks")
def chargebacks(db: Session = Depends(get_db)):
    rows = db.query(Chargeback).all()
    return [{"id":d.id,"case_ref":d.case_ref,"transaction_ref":d.transaction_ref,
        "reason":d.reason,"amount":d.amount,"due_date":d.due_date,"status":d.status} for d in rows]

@router.get("/reports/metrics")
def report_metrics(db: Session = Depends(get_db)):
    summary = dashboard_summary(db)
    return {"summary":summary,"risk_policy":[
        {"band":"Approve","range":"0–24","action":"Authorize and monitor"},
        {"band":"Challenge","range":"25–49","action":"Step-up authentication"},
        {"band":"Review","range":"50–74","action":"Hold for analyst review"},
        {"band":"Decline","range":"75–100","action":"Reject and log rationale"}
    ]}
