def detect_card_testing(amount: float, attempts_10m: int, device_id: str):
    signals = []
    score = 0
    if amount <= 5 and attempts_10m >= 8:
        score += 45
        signals.append("Micro-authorization pattern combined with high velocity")
    if attempts_10m >= 20:
        score += 20
        signals.append("Burst pattern consistent with card enumeration/testing")
    if device_id.startswith("dev-bot"):
        score += 15
        signals.append("Known synthetic bot-like device fingerprint in demo dataset")
    return min(score, 80), signals
