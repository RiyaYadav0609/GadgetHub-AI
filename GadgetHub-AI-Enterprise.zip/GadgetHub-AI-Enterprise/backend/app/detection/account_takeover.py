def account_risk(account_age_days: int, device_id: str):
    score, signals = 0, []
    if account_age_days <= 3:
        score += 18
        signals.append("Very new account (3 days or less)")
    if account_age_days <= 14:
        score += 8
        signals.append("Account age is under 14 days")
    if device_id.startswith("dev-77"):
        score += 12
        signals.append("Unfamiliar device signal in demo profile")
    return score, signals
