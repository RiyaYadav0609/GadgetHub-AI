def dashboard_summary(db):
    from app.models.entities import Transaction, FraudAlert, Chargeback
    tx = db.query(Transaction).all()
    alerts = db.query(FraudAlert).all()
    disputes = db.query(Chargeback).all()
    total = len(tx)
    flagged = sum(1 for t in tx if t.decision != "APPROVE")
    blocked = sum(1 for t in tx if t.decision == "DECLINE")
    volume = sum(t.amount for t in tx)
    return {
        "total_transactions": total,
        "payment_volume": round(volume, 2),
        "flagged_transactions": flagged,
        "blocked_transactions": blocked,
        "open_alerts": sum(1 for a in alerts if a.status == "OPEN"),
        "open_disputes": sum(1 for d in disputes if d.status != "WON"),
        "estimated_fraud_prevented": round(sum(t.amount for t in tx if t.decision == "DECLINE"), 2),
        "approval_rate": round((sum(1 for t in tx if t.decision == "APPROVE") / total * 100), 1) if total else 0
    }
