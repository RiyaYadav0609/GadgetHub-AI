from app.detection.card_testing import detect_card_testing
from app.detection.address_risk import address_risk
from app.detection.account_takeover import account_risk
from app.detection.velocity_rules import velocity_risk

def assess_transaction(amount: float, new_address: bool, attempts_10m: int,
                       account_age_days: int, device_id: str):
    score, reasons = 0, []
    points, signals = detect_card_testing(amount, attempts_10m, device_id)
    score += points; reasons += signals
    points, signals = address_risk(new_address, amount)
    score += points; reasons += signals
    points, signals = account_risk(account_age_days, device_id)
    score += points; reasons += signals
    points, signals = velocity_risk(attempts_10m)
    score += points; reasons += signals
    score = min(100, score)
    if score >= 75: decision = "DECLINE"
    elif score >= 50: decision = "REVIEW"
    elif score >= 25: decision = "CHALLENGE"
    else: decision = "APPROVE"
    if not reasons: reasons = ["No elevated risk signals detected"]
    return score, decision, reasons
