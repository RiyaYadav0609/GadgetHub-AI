No pretrained model is included. The demo uses explainable rule scoring in app/services/fraud_service.py. Replace with a validated model only after labeled data and evaluation.
