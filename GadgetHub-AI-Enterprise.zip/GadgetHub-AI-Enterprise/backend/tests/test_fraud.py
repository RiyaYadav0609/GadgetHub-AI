from app.services.fraud_service import assess_transaction

def test_normal_transaction_approves():
    score, decision, reasons = assess_transaction(1200, False, 1, 500, "device-a")
    assert decision == "APPROVE"
    assert score < 25

def test_card_testing_is_declined():
    score, decision, reasons = assess_transaction(1, False, 60, 1, "dev-bot-7")
    assert decision == "DECLINE"
    assert score >= 75
