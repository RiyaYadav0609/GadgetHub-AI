@echo off
cd /d %~dp0..\backend
call ..\.venv\Scripts\activate
set PYTHONPATH=.
pytest -q
pause
