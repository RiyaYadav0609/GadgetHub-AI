@echo off
cd /d %~dp0..
python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r backend\requirements.txt
cd frontend
npm install
echo.
echo Setup complete. Use scripts\start_backend.bat and scripts\start_frontend.bat in separate terminals.
pause
